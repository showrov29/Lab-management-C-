﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabHub
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-28M7BPF;Initial Catalog=Lab_P1;Integrated Security=True");

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void getTeacherInfo()
        {

            SqlCommand cmd = new SqlCommand("Select * from Teacher ", conn);

            DataTable dt = new DataTable();
            conn.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            conn.Close();

            dataGridView1.DataSource = dt;
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            getTeacherInfo();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form6.res1 = 0;
        }
    }
}
