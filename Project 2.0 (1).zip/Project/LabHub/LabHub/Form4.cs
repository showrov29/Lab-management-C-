﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabHub
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        SqlConnection conn=new SqlConnection(@"Data Source=DESKTOP-28M7BPF;Initial Catalog=Lab_P1;Integrated Security=True");

        private void Form4_Load(object sender, EventArgs e)
        {
            textBox1.Text = Form5.id;
            //textBox1.Visible = false;
        }
        string ID=Form5.id;
        private void button1_Click(object sender, EventArgs e)
        {
            //string ID = Form5.id;
            if (conn.State == ConnectionState.Closed)
            {
               /* conn.Open();
                string query = "SELECT * FROM Section_1 WHERE ID=@ID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.CommandType=CommandType.Text;
                cmd.Parameters.AddWithValue("@ID", ID);*/

                GetStudentRecordsRecord();
            }
        }
        private void GetStudentRecordsRecord()
        {

            SqlCommand cmd = new SqlCommand("Select * from Section_1 where ID=@ID", conn);
            cmd.Parameters.AddWithValue("@ID", ID);
            DataTable dt = new DataTable();
            conn.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            conn.Close();

            dataGridView1.DataSource = dt;
        }




        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            GetHwRecord();
        }
        private void GetHwRecord()
        {

            SqlCommand cmd = new SqlCommand("Select * from Homework", conn);

            DataTable dt = new DataTable();

            if (conn.State == ConnectionState.Closed)
                conn.Open();




            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            //conn.Close();

            dataGridView1.DataSource = dt;
            if (conn.State == ConnectionState.Open)
                conn.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 f5=new Form5();
            this.Hide();
            f5.Show();
        }
    }
}
