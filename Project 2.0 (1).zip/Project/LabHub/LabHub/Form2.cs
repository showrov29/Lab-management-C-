﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabHub
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        string user = "1";
        string password = "2";
        
        //SqlConnection conn= new SqlConnection(@"Data Source=DESKTOP-28M7BPF;Initial Catalog=TestAdmin;Integrated Security=True");
        
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked==true)
            textBox2.UseSystemPasswordChar = false;
            else
                textBox2.UseSystemPasswordChar = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show(" Username or Password cannot be empty");
                textBox1.Focus();
            }
            else
            {

                if (textBox1.Text == user && textBox2.Text == password)
                {
                    this.Hide();
                    Form6 ad = new Form6();
                    ad.Show();
                }
                else
                {
                    MessageBox.Show("Incorrect Id or Password");
                    textBox1.Focus();
                }
               
            }

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f2=new Form1();
            this.Hide();
            f2.Show();
        }
    }
}
