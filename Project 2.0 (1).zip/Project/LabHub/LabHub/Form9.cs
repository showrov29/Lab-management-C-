﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabHub
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-28M7BPF;Initial Catalog=Lab_P1;Integrated Security=True");


        private void getStudentInfo()
        {
            SqlCommand cmd = new SqlCommand("Select * from Student ", conn);

            DataTable dt = new DataTable();
            conn.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            conn.Close();

            dataGridView1.DataSource = dt;
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            getStudentInfo();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form6.res2 = 0;
        }
    }
}
