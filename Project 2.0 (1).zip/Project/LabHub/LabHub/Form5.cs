﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabHub
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-28M7BPF;Initial Catalog=Lab_P1;Integrated Security=True");


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
                textBox2.UseSystemPasswordChar = false;
            else
                textBox2.UseSystemPasswordChar = true;
        }

        public static string id;
        public void button1_Click(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
                string query = "SELECT COUNT(1) FROM Student WHERE ID=@ID AND Password=@Password" ;
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ID", textBox1.Text);
                cmd.Parameters.AddWithValue("@Password",textBox2.Text);
                int count = Convert.ToInt32(cmd.ExecuteScalar());

                if (count == 1)
                {
                    this.Hide();
                    id = textBox1.Text;
                    Form4 sd = new Form4();

                    sd.Show();
                }
                else
                {
                    MessageBox.Show("Incorrect Username or Password" );
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox1.Focus();
                    
            
                }

            }
           

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f6=new Form1();
            this.Hide();
            f6.Show();

        }
    }
}
