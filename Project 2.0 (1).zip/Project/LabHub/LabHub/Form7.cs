﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabHub
{
    public partial class TeacherForm : Form
    {
        public TeacherForm()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-28M7BPF;Initial Catalog=Lab_P1;Integrated Security=True");


        private void TeacherForm_Load(object sender, EventArgs e)
        {
            //GetSectionRecord();
        }

        
        private void GetSectionRecord()
        {

            SqlCommand cmd = new SqlCommand("Select * from Section_1 ", conn);

            DataTable dt = new DataTable();

            if(conn.State==ConnectionState.Closed)
            conn.Open();




            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            //conn.Close();

            dataGridView1.DataSource = dt;

            if (conn.State==ConnectionState.Open)
            conn.Close();

        }
        private void GetHwRecord()
        {

            SqlCommand cmd = new SqlCommand("Select * from Homework", conn);

            DataTable dt = new DataTable();

            if(conn.State==ConnectionState.Closed)
            conn.Open();




            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            //conn.Close();

            dataGridView1.DataSource = dt;
            if(conn.State==ConnectionState.Open)
            conn.Close();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox1.Text= dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //GetSectionRecord();
            //GetHwRecord();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlCommand cl = new SqlCommand("UPDATE Section_1 SET Grade=@grade WHERE ID=@id", conn);
                conn.Open();
                cl.Parameters.AddWithValue("@id", textBox1.Text);
                cl.Parameters.AddWithValue("@grade", textBox2.Text);
                if(string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("Please Select Or Enter ID");
                    conn.Close();
                }
                else
                {
                    cl.CommandType = CommandType.Text;
                    cl.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Updated Successfuly");
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox1.Focus();

                }
               


            }
            catch (Exception ex)
            {
                MessageBox.Show("Id not found ");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                SqlCommand cl = new SqlCommand("INSERT INTO Homework VALUES (@Date,@Topic)", conn);
                conn.Open();
                cl.Parameters.AddWithValue("@Date", textBox3.Text);
                cl.Parameters.AddWithValue("@Topic", textBox4.Text);
                    
                if (string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text))
                {
                    MessageBox.Show("No topic is written");
                }


                else
                {
                    cl.CommandType = CommandType.Text;
                    cl.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Inserted Successfuly");
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox3.Focus();

                }




            }
            catch (Exception ex)
            {
                MessageBox.Show("");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            GetHwRecord();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            GetSectionRecord();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            this.Hide();
            f3.Show();
        }
    }
}
