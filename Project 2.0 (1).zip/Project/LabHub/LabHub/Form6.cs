﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LabHub
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-28M7BPF;Initial Catalog=Lab_P1;Integrated Security=True");
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void GetSectionRecord()
        {

            SqlCommand cmd = new SqlCommand("Select * from Section_1 ", conn);
           
            DataTable dt = new DataTable();
           
            
                conn.Open();
            
            
            

                SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                //conn.Close();

                dataGridView1.DataSource = dt;

            conn.Close();
            
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            GetSectionRecord();
        }

       
        public  static string id;
        public static string name;

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                SqlCommand cmd = new SqlCommand("SELECT ID,Name FROM Student where ID=@id", conn);

                conn.Open();


                cmd.Parameters.AddWithValue("@id", textBox1.Text);
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    if (sdr.Read())
                    {

                        textBox1.Text = sdr["ID"].ToString();
                        textBox2.Text = sdr["Name"].ToString();
                        //conn.Close();



                    }

                }
                // conn.Close();


               if(string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
                {
                    MessageBox.Show("No ID selected");
                    conn.Close();
                }
                else
                {

                    SqlCommand cmds = new SqlCommand("INSERT INTO Section_1 VALUES (@ID,@Name,@Grade)", conn);

                    cmds.CommandType = CommandType.Text;
                    cmds.Parameters.AddWithValue("@ID", textBox1.Text);
                    cmds.Parameters.AddWithValue("@Name", textBox2.Text);
                    cmds.Parameters.AddWithValue("@Grade", "00");


                    cmds.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Successfuly Inserted");
                    textBox1.Clear();
                    textBox1.Focus();
                   
                }

                /*
                            ;*/





                // conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No such Id in database or This Id is already inserted");
                conn.Close();

            }



        }

        private void button5_Click(object sender, EventArgs e)
        {
            GetSectionRecord();
        }

        public static int res1 = 0;
        public static int res2 = 0;
        private void button6_Click(object sender, EventArgs e)
        {
            Form8 tabl= new Form8();
            if(res1==0)
            {
                tabl.Show();
                res1++;
            }
            else
            {
                MessageBox.Show("Form already opend");
            }
           
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
            Form9 tb = new Form9();

            if (res2 == 0)
            {
                tb.Show();
                res2++;
            }
            else
            {
                MessageBox.Show("Form already opend");
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlCommand clear = new SqlCommand("DELETE Section_1",conn);
            if(conn.State==ConnectionState.Closed)
            {
                conn.Open();
                clear.CommandType = CommandType.Text;
                clear.ExecuteNonQuery();
                conn.Close();
            }
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Clear();
            textBox1.Text=dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlCommand cl = new SqlCommand("DELETE FROM Section_1 WHERE ID=@id", conn);
            conn.Open();
            cl.Parameters.AddWithValue("@id", textBox1.Text);
            cl.CommandType = CommandType.Text;
            cl.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Removed Successfuly");
            textBox1.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f1 = new Form2();
            f1.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            

                try
                {
                    SqlCommand cmsd = new SqlCommand("SELECT ID,Name FROM Teacher where ID=@id", conn);

                    conn.Open();


                    cmsd.Parameters.AddWithValue("@id", textBox1.Text);
                    using (SqlDataReader sdr = cmsd.ExecuteReader())
                    {
                        if (sdr.Read())
                        {

                            textBox1.Text = sdr["ID"].ToString();
                            textBox2.Text = sdr["Name"].ToString();
                            //conn.Close();



                        }

                    }
                    // conn.Close();


                    if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
                    {
                        MessageBox.Show("No ID selected");
                        conn.Close();
                    }
                    else
                    {

                        SqlCommand cmddd = new SqlCommand("INSERT INTO Section_1 VALUES (@ID,@Name,@Grade)", conn);

                        cmddd.CommandType = CommandType.Text;
                        cmddd.Parameters.AddWithValue("@ID", textBox1.Text);
                        cmddd.Parameters.AddWithValue("@Name", textBox2.Text);
                        cmddd.Parameters.AddWithValue("@Grade", "00");


                        cmddd.ExecuteNonQuery();
                        conn.Close();
                        MessageBox.Show("Successfuly Inserted");
                        textBox1.Clear();
                        textBox1.Focus();

                    }

                    /*
                                ;*/





                    // conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No such Id in database or This Id is already inserted");
                    conn.Close();

                }



            
        }
    }
}
